var express = require('express');
var app = express();
var mysql= require('mysql');
const http = require('http');
const server = http.createServer(app)
const { Server } = require("socket.io");
var bodyParser=require('body-parser');
const io = new Server(server);
app.use(express.static(__dirname + '/public'));
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view-engine','ejs');
var os=require('os');
var network=os.networkInterfaces();
var networksIps=[];
for (const Ips of Object.keys(network)) {    
    networksIps.push(network[Ips][1]['address']);
}
app.get('/',function(req,res){
res.render('index.ejs');
})
server.listen(9990);